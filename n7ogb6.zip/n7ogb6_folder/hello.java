import java.util.Scanner;
class A 
{
    public static void main(String args[])
    {
        System.out.println("Hello world");
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        System.out.println("The number you entered is :"+a);
        String b = sc.nextLine();
        b = sc.nextLine();
        System.out.print("Your name was :"+b);
    }
}
